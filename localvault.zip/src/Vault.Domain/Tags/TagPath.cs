namespace Vault.Domain.Tags;

public sealed record TagPath
{
    public static readonly TagPath Empty = new([]);

    public IReadOnlyList<string> Segments { get; }

    private TagPath(IReadOnlyList<string> segments)
    {
        Segments = segments;
    }

    public static TagPath From(IEnumerable<string> segments)
    {
        ArgumentNullException.ThrowIfNull(segments);

        var normalized = segments
            .Select(Normalize)
            .Where(s => !string.IsNullOrWhiteSpace(s))
            .ToArray();

        return normalized.Length == 0
            ? Empty
            : new TagPath(normalized);
    }

    public static TagPath FromSingle(string segment)
        => From(new[] { segment });

    public TagPath Append(string segment)
        => From(Segments.Append(segment));

    public override string ToString()
        => Segments.Count == 0
            ? string.Empty
            : string.Join(" / ", Segments);

    private static string Normalize(string value)
        => value.Trim();
}
