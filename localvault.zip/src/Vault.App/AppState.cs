using Vault.Application.Models;

namespace Vault.App;

public sealed class AppState
{
    public string? CurrentVaultPath { get; private set; }
    public VaultDocument? UnlockedDocument { get; private set; }

    // Session Key (in RAM). Do not persist.
    public byte[]? SessionKey { get; private set; }

    public bool IsUnlocked => UnlockedDocument is not null && SessionKey is not null;

    public void SetUnlocked(string path, VaultDocument doc, byte[] sessionKey)
    {
        CurrentVaultPath = path;
        UnlockedDocument = doc;
        SessionKey = sessionKey;
    }

    public void Lock()
    {
        CurrentVaultPath = null;
        UnlockedDocument = null;

        if (SessionKey is not null)
        {
            Array.Clear(SessionKey, 0, SessionKey.Length);
            SessionKey = null;
        }
    }
}

