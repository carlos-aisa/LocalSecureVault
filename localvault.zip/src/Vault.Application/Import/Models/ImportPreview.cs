
namespace Vault.Application.Import.Models;

public sealed class ImportPreview
{
    public IReadOnlyList<ImportEntryPreview> Entries { get; init; } = [];
    public IReadOnlyList<ImportIssue> Issues { get; init; } = [];
}
