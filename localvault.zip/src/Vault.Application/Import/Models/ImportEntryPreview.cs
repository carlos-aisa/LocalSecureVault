using Vault.Domain.Tags;
namespace Vault.Application.Import.Models;

public sealed class ImportEntryPreview
{
    public string Name { get; init; } = "";
    public string? Username { get; init; }
    public string Password { get; init; } = "";
    public string? Extra { get; init; }

    public TagPath TagPath { get; init; } = TagPath.Empty;

    public bool IsDuplicate { get; init; }
    public int Line { get; init; }
}
